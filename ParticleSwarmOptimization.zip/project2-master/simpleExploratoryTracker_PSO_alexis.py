#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 2019

@author: amm0153
"""

import os
import random
import sys
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

#
#  A Simple Steady-State, Real-Coded Genetic Algorithm       
#
    
class aParticle:
    def __init__(self, specified_vector_length):
        self.vector_length = specified_vector_length
        self.x_vector = []
        self.p_vector = []
        self.v_vector = []
        self.x_fitness = 0
        self.p_fitness = 0
        
    def randomly_generate(self,lb, ub):
        for i in range(self.vector_length):
            self.x_vector.append(random.uniform(lb, ub))
            self.p_vector.append(0)#self.x_vector[i])
            self.v_vector.append(0)
        self.x_fitness = 0.5
        self.p_fitness = 0.5
    
    def calculate_fitness(self):
        x2y2 = self.x_vector[0]**2 + self.x_vector[1]**2
        self.x_fitness = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
        if self.x_fitness > self.p_fitness:
            self.p_fitness = self.x_fitness
        if self.x_fitness > self.p_fitness:
            self.p_vector = self.x_vector
    
    def print_individual(self, i):
        print("X-Vector "+str(i) +": \t " + str(self.x_vector) + "  \t X-Fitness: \t " + str(self.x_fitness))
        print("P-Vector "+str(i) +": \t " + str(self.p_vector) + "  \t P-Fitness: \t " + str(self.p_fitness))
        #print("V-Vector "+str(i) +": \t\t " + str(self.v_vector))
        
class aSimpleExploratoryAttacker:
    def __init__(self, population_size, vector_length, mutation_rate, lb, ub):
        if (population_size < 2):
            print("Error: Population Size must be greater than 2")
            sys.exit()
        self.population_size = population_size
        self.vector_length = vector_length
        self.mutation_amt = mutation_rate #########################SAME THING
        self.lb = lb
        self.ub = ub
        self.mutation_amt = mutation_rate * (ub - lb)##############SAME THING
        self.population = []
        self.hacker_tracker_x = []
        self.hacker_tracker_y = []
        self.hacker_tracker_z = []
        
    def generate_initial_population(self):
        for i in range(self.population_size):
            individual = aParticle(self.vector_length)
            individual.randomly_generate(self.lb,self.ub)
            individual.calculate_fitness()
            self.hacker_tracker_x.append(individual.x_vector[0])
            self.hacker_tracker_y.append(individual.x_vector[1])
            self.hacker_tracker_z.append(individual.x_fitness)
            self.population.append(individual)
    
    def get_best_fitness(self):
        best_fitness = -99999999999.0
        best_individual = -1
        for i in range(self.population_size):
            if self.population[i].p_fitness > best_fitness:
                best_fitness = self.population[i].p_fitness
                best_individual = i
        return best_fitness
    
    def get_best_individual(self):
        best_fitness = -99999999999.0
        best = -1
        for i in range(self.population_size):
            if self.population[i].p_fitness > best_fitness:
                best = i
        #best_individual = self.population[best]
        return best
    
    def evolutionary_cycle(self):
        #Synchronous
        best = self.get_best_individual()
        
        K = 2/abs(2 - phi - math.sqrt((phi ** 2) - (4*phi)))
#        updates = updates
#        topography = topography
        """
        v(id) = K*(v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id)))
        """
        '''
        for i in range(self.population_size):
            #Asynchronous
            #best = self.get_best_individual()
            if self.population[i].x_fitness > self.population[i].p_fitness:
                self.population[i].p_fitness = self.population[i].x_fitness
                self.population[i].p_vector = self.population[i].x_vector
            for j in range(self.vector_length):
                self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
            
                #if self.population[i].x_vector[j] > self.ub:
                #    self.population[i].x_vector[j] = self.ub
                #if self.population[i].x_vector[j] < self.lb:
                #    self.population[i].x_vector[j] = self.lb
                
            self.population[i].calculate_fitness()
            #Star Topography
#            if self.population[i].x_fitness > self.population[i].p_fitness:
#                self.population[i].p_fitness = self.population[i].x_fitness
#                self.population[i].p_vector = self.population[i].x_vector
            #Ring Topography
            ln = i-1
            un = i+1
            if i == 0:
                ln  = len(self.population)-1
                un = 1
            if i == len(self.population)-1:
                ln = len(self.population)-1-1
                un = 0
            if self.population[i].x_fitness > self.population[ln].x_fitness:
#                self.population[i].x_fitness = self.population[ln].x_fitness
#                self.population[i].x_vector = self.population[ln].x_vector
                self.population[i].p_fitness = self.population[ln].p_fitness
                self.population[i].p_vector = self.population[ln].p_vector
#            if self.population[i].x_fitness > self.population[i].p_fitness:
#                self.population[i].p_fitness = self.population[i].x_fitness
#                self.population[i].p_vector = self.population[i].x_vector
            if self.population[i].x_fitness > self.population[un].x_fitness:
#                self.population[i].x_fitness = self.population[un].x_fitness
#                self.population[i].x_vector = self.population[un].x_vector
                self.population[i].p_fitness = self.population[un].p_fitness
                self.population[i].p_vector = self.population[un].p_vector
#            if self.population[i].x_fitness > self.population[i-1].x_fitness:
#                self.population[i].x_fitness = self.population[i-1].x_fitness
#                self.population[i].x_vector = self.population[i-1].x_vector
#            if self.population[i].x_fitness > self.population[i+1].x_fitness:
#                self.population[i].x_fitness = self.population[i+1].x_fitness
#                self.population[i].x_vector = self.population[i+1].x_vector
#        if self.population[i].x_fitness > self.population[i].p_fitness:
#            self.population[i].p_fitness = self.population[i].x_fitness
#            self.population[i].p_vector = self.population[i].x_vector
        '''

        '''
        # Ring Synchronous
        for i in range(self.population_size):
            #if updates == 'synchronous'
            #Synchronous
            for j in range(self.vector_length):
                self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
            self.population[i].calculate_fitness()
            
            #Ring Topography
            #if topography == 'ring'
            ln = i-1
            un = i+1
            if i == 0:
                ln  = len(self.population)-1
                un = 1
            if i == len(self.population)-1:
                ln = len(self.population)-1-1
                un = 0
            if self.population[i].x_fitness > self.population[ln].x_fitness:
                self.population[i].p_fitness = self.population[ln].p_fitness
                self.population[i].p_vector = self.population[ln].p_vector
            if self.population[i].x_fitness > self.population[un].x_fitness:
                self.population[i].p_fitness = self.population[un].p_fitness
                self.population[i].p_vector = self.population[un].p_vector
        '''

        '''
        #Ring Asynchronous 
        for i in range(self.population_size):
            #Asynchronous Updates
            #if updates == 'asynchronous'
            if self.population[i].x_fitness > self.population[i].p_fitness:
                self.population[i].p_fitness = self.population[i].x_fitness
                self.population[i].p_vector = self.population[i].x_vector
            for j in range(self.vector_length):
                self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
            self.population[i].calculate_fitness()
            
            #Ring Topography
            # if topography == 'ring'
            ln = i-1
            un = i+1
            if i == 0:
                ln  = len(self.population)-1
                un = 1
            if i == len(self.population)-1:
                ln = len(self.population)-1-1
                un = 0
            if self.population[i].x_fitness > self.population[ln].x_fitness:
                self.population[i].p_fitness = self.population[ln].p_fitness
                self.population[i].p_vector = self.population[ln].p_vector
            if self.population[i].x_fitness > self.population[un].x_fitness:
                self.population[i].p_fitness = self.population[un].p_fitness
                self.population[i].p_vector = self.population[un].p_vector
        '''

        '''
        #Star Synchronous
        for i in range(self.population_size):
            #Synchronous Updates
            #if updates == 'synchronous'
            for j in range(self.vector_length):
                self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
            self.population[i].calculate_fitness()
            
            #Star Topography
            #if topography == 'star'
            if self.population[i].x_fitness > self.population[i].p_fitness:
                self.population[i].p_fitness = self.population[i].x_fitness
                self.population[i].p_vector = self.population[i].x_vector
        '''

        '''
        #Star Asynchronous
        for i in range(self.population_size):
            #Asynchronous Updates
            #if updates == 'asynchronous'
            if self.population[i].x_fitness > self.population[i].p_fitness:
                self.population[i].p_fitness = self.population[i].x_fitness
                self.population[i].p_vector = self.population[i].x_vector
            for j in range(self.vector_length):
                self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
            self.population[i].calculate_fitness()

            #Star Topography
            #if topography == 'star'
            if self.population[i].x_fitness > self.population[i].p_fitness:
                self.population[i].p_fitness = self.population[i].x_fitness
                self.population[i].p_vector = self.population[i].x_vector
        '''
#        '''
        #MAIN
        for i in range(self.population_size):
            #Asynchronous Updates
            if updates == 'asynchronous':
                if self.population[i].x_fitness > self.population[i].p_fitness:
                    self.population[i].p_fitness = self.population[i].x_fitness
                    self.population[i].p_vector = self.population[i].x_vector
                for j in range(self.vector_length):
                    self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                    self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
                self.population[i].calculate_fitness()
            
            #Synchronous Updates
            if updates == 'synchronous':
                for j in range(self.vector_length):
                    self.population[i].v_vector[j] = K*(self.population[i].v_vector[j] + phi1*random.random()*(self.population[i].p_vector[j]-self.population[i].x_vector[j]) + phi2*random.random()*(self.population[best].p_vector[j]-self.population[i].x_vector[j]))
                    self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j]
                self.population[i].calculate_fitness()
            
            #Star Topography
            if topography == 'star':
                if self.population[i].x_fitness > self.population[i].p_fitness:
                    self.population[i].p_fitness = self.population[i].x_fitness
                    self.population[i].p_vector = self.population[i].x_vector
            
            #Ring Topography
            if topography == 'ring':
                ln = i-1
                un = i+1
                if i == 0:
                    ln  = len(self.population)-1
                    un = 1
                if i == len(self.population)-1:
                    ln = len(self.population)-1-1
                    un = 0
                if self.population[i].x_fitness > self.population[ln].x_fitness:
                    self.population[i].p_fitness = self.population[ln].p_fitness
                    self.population[i].p_vector = self.population[ln].p_vector
                if self.population[i].x_fitness > self.population[un].x_fitness:
                    self.population[i].p_fitness = self.population[un].p_fitness
                    self.population[i].p_vector = self.population[un].p_vector
#        '''

    def print_population(self):
        for i in range(self.population_size):
            self.population[i].print_individual(i)
    
    def print_best_max_fitness(self):
        best_fitness = -999999999.0  # For Maximization
        best_individual = -1
        for i in range(self.population_size):
            if self.population[i].p_fitness > best_fitness:
                best_fitness = self.population[i].p_fitness
                best_individual = i
        print("Best Individual: ",str(best_individual)," \t", self.population[best_individual].p_vector, "\t P-Fitness: \t", str(best_fitness))
    
    def plot_evolved_candidate_solutions(self):
        fig = plt.figure()
        ax1 = fig.add_subplot(1,1,1,projection='3d')
        ax1.scatter(self.hacker_tracker_x,self.hacker_tracker_y,self.hacker_tracker_z)
        plt.title("Evolved Candidate Solutions")
        ax1.set_xlim3d(-100.0,100.0)
        ax1.set_ylim3d(-100.0,100.0)
        ax1.set_zlim3d(0.2,1.0)
        plt.show()

VectorLength = 2
ub = 100.0
lb = -100.0
MaxEvaluations = 4000
plot = 0

PopSize = 30#300
mu_amt  = 0.012
omega = 1.0
output = ""

"""
# Swarm Search 
v(id) = v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id))
x(id) = x(id) + v(id)


# The Inertia Factor
w = 1.0 #initialized #this will be gradually reduced over time
v(id) = w*v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id))
x(id) = x(id) + v(id)
"""

# Constriction Coefficient
phi1 = 2.05#3.05
phi2 = 2.05#3.05

phi = phi1 + phi2 #phi > 4  #4.10

updates = 'asynchronous'
#updates = 'synchronous'
topography = 'ring'
#topography = 'star'

"""
K = 2/abs(2 - phi - sqrt((phi^2) - (4*phi)))
v(id) = K*(v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id)))
x(id) = x(id) + v(id)



# Full Model 
phi1 = 1 # phi1 > 0
phi2 = 1 # phi2 > 0
# Cognition Only 
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
# Social Only
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
# Selfless
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
g = 1 #g =/= i

# Asynchronous Update
# The Asynchronous Particle Update Method allows for newly discovered solutions to be used more quickly.
# similar to SSGA


# Synchronous Update
# The Synchronous Particle Update Method allows for ....
# similar to GGA
"""

for n in range(30):
    simple_exploratory_attacker = aSimpleExploratoryAttacker(PopSize,VectorLength,mu_amt,lb,ub)
    
    simple_exploratory_attacker.generate_initial_population()
#    simple_exploratory_attacker.print_population()
    
    for i in range(MaxEvaluations-PopSize+1):
        simple_exploratory_attacker.evolutionary_cycle()
        if (i % PopSize == 0):
            if (plot == 1):
                simple_exploratory_attacker.plot_evolved_candidate_solutions()
            #print("At Iteration: " + str(i))
            #simple_exploratory_attacker.print_population()
        if (simple_exploratory_attacker.get_best_fitness() >= 0.99754):
            break
    
    print("\nFinal Population\n")
    simple_exploratory_attacker.print_population()
    simple_exploratory_attacker.print_best_max_fitness()
    #print("Function Evaluations: " + 
    print(str(PopSize+i))
    output += str(PopSize+i) + "\n"
    simple_exploratory_attacker.plot_evolved_candidate_solutions()
    
    #f1individual = simple_exploratory_attacker.print_best_max_fitness().best_individual
    #f1 = simple_exploratory_attacker.print_best_max_fitness().population[simple_exploratory_attacker.print_best_max_fitness.best_individual].chromosome,best_fitness

print(output)

#for n in range(30):
#    results()


#    results_SSGA = results(n+1)
    

#class results(n):
#    def population(n):
#        population[n] = simple_exploratory_attacker.print_population()
#        return population[n]
#    def worst(n):
#        def worst_individual(n): 
#            worst_individual[n] = simple_exploratory_attacker.get_worst_fit_individual(worst_individual)
#            return worst_individual[n]
#        def worst_fitness(): 
#            worst_fitness = simple_exploratory_attacker.get_worst_fit_fitness(worst_fitness)
#            return worst_fitness
#        return worst
#    def best(n):
#        def best_individual(n): 
#            best_individual = simple_exploratory_attacker.get_best_fit_individual(best_individual)
#            return best_individual
#        def best_fitness(n): 
#            best_fitness = simple_exploratory_attacker.get_best_fit_fitness(best_fitness)
#            return best_fitness
#        return best
#    def best_max(n):
#        def best_individual(n): 
#            best_individual = simple_exploratory_attacker.get_best_max_fit_individual(best_individual)
#            return best_individual
#        def best_fitness(n): 
#            best_fitness = simple_exploratory_attacker.get_best_max_fit_fitness(best_fitness)
#            return best_fitness
#        return best_max
#
#            
#    results.population = simple_exploratory_attacker.print_population()
#    results.worst.worst_individual = simple_exploratory_attacker.get_worst_fit_individual.worst_individual
#    results.worst.worst_fitness = simple_exploratory_attacker.get_worst_fitness(worst_fitness)
#    results.best.best_individual = simple_exploratory_attacker.print_best_fitness(best_individual)
#    results.best.best_fitness = simple_exploratory_attacker.print_best_fitness(best_fitness)
#    results.best_max.best_individual = simple_exploratory_attacker.print_best_max_fitness(best_individual)
#    results.best_max.best_fitness = simple_exploratory_attacker.print_best_max_fitness()
#
#
#
#print(results.best_max.best_fitness)


    


    
