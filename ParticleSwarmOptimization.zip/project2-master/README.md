# Project2


## Notes: 

The MAIN code contains all of the combinations of Asynchronous vs. Synchronous Updates and Ring vs. Star Topologies. 

Simply specify which combinations you want to run, and the code will run it. 

I have not tested the MAIN code for each combination, yet. However, if you run into an overflow error, you may need to change phi1 to 3.05. 

## Report: 

Reference ParticleSwarmOptimization.ppt

4 to 5 pgs. long.

Make sure we are all using the same population size, phi1, and phi2 values-> use the optimal one from our class discussion.

