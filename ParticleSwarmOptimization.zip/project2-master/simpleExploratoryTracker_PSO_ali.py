#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 22:42:12 2019

@author: alj0032
"""

import os
import random
import sys
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

#
#  A Simple Steady-State, Real-Coded Genetic Algorithm       
#
    
class anIndividual:
    def __init__(self, specified_vector_length):
        self.vector_length = specified_vector_length
        self.x_vector = []
        self.p_vector = []
        self.v_vector = []
        self.x_fitness = 0
        self.p_fitness = 0
        
    def randomly_generate(self,lb, ub):
        for i in range(self.vector_length):
            self.x_vector.append(random.uniform(lb, ub))
            self.p_vector.append(self.x_vector[i])
            self.v_vector.append(random.uniform(lb, ub))
        self.x_fitness = 0.5
        self.p_fitness = 0.5
    
    def calculate_fitness(self):
        x2y2 = self.x_vector[0]**2 + self.x_vector[1]**2
        self.x_fitness = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
        if self.x_fitness > self.p_fitness:
            self.p_fitness = self.x_fitness
            self.p_vector = self.x_vector 
    
    def print_individual(self, i):
        print("X-Vector "+str(i) +": \t\t " + str(self.x_vector) + "  \t X-Fitness: \t " + str(self.x_fitness))
      
class aSimpleExploratoryAttacker:
    def __init__(self, population_size, vector_length, mutation_rate, lb, ub):
        if (population_size < 2):
            print("Error: Population Size must be greater than 2")
            sys.exit()
        self.population_size = population_size
        self.vector_length = vector_length
        self.lb = lb
        self.ub = ub
        self.mutation_amt = mutation_rate * (ub - lb) 
        self.population = []
        self.hacker_tracker_x = []
        self.hacker_tracker_y = []
        self.hacker_tracker_z = []
        
    def generate_initial_population(self):
        for i in range(self.population_size):
            individual = anIndividual(self.vector_length)
            individual.randomly_generate(self.lb,self.ub)
            individual.calculate_fitness()
            self.hacker_tracker_x.append(individual.x_vector[0])
            self.hacker_tracker_y.append(individual.x_vector[1])
            self.hacker_tracker_z.append(individual.x_fitness)
            self.population.append(individual)
    
    def get_best_fitness(self):
        best_fitness = -99999999999.0
        best_individual = -1
        for i in range(self.population_size):
            if self.population[i].p_fitness > best_fitness:
                best_fitness = self.population[i].p_fitness
                best_individual = i
        self.population[i].x_fitness = self.population[best_individual].x_fitness
        self.population[i].x_vector = self.population[best_individual].x_vector
        return best_fitness
    
    def get_best_individual(self):
        best_fitness = -99999999999.0
        best_individual = -1
        for i in range(self.population_size):
            if self.population[i].p_fitness > best_fitness:
                best_fitness = self.population[i].p_fitness
                best_individual = i
        best_individual = self.population[best_individual]
        return best_individual
    
    def select_parent(self):
        parent = random.randint(0,self.population_size-1)
        return parent
    
    def neighborhood_check(self):
        neighbor1 = self.population[i-1]
        neighbor2 = self.population[i+1]
        if neighbor1.x_fitness > self.population[i].x_fitness:
            self.population[i].x_fitness = neighbor1.x_fitness
            self.population[i].x_vector = neighbor1.x_vector
        if neighbor2.x_fitness > self.population[i].x_fitness:
            self.population[i].x_fitness = neighbor2.x_fitness
            self.population[i].x_vector = neighbor2.x_vector
        return self.population[i]
        
    def evolutionary_cycle(self):
        global_best = self.get_best_individual()
        for i in range(self.population_size):
            self.population[i].calculate_fitness()
#        for i in range(1):
#            global_best = self.get_best_individual()
#        for i in range(self.population_size):
#            if self.x_fitness > self.p_fitness:
#               self.p_fitness = self.x_fitness
#               self.p_vector = self.x_vector
        for j in range(self.vector_length):
            self.population[i].v_vector[j] = K*(w*self.population[i].v_vector[j] + phi1*(self.population[i].p_vector[j]-self.population[i].x_vector[j])+ phi2*(global_best.p_vector[j]-self.population[i].x_vector[j]))
            self.population[i].x_vector[j] = self.population[i].x_vector[j] + self.population[i].v_vector[j] 
#            self.population[i].p_vector[j] = self.population[i].p_vector[j] + mu_amt*global_best.p_vector[j]# + 3*mu_amt*global_best.x_vector[j]
#        global_best = self.get_best_individual()

    def print_population(self):
        for i in range(self.population_size):
            self.population[i].print_individual(i)
    
    def print_best_max_fitness(self):
        best_fitness = -999999999.0  # For Maximization
        best_individual = -1
        for i in range(self.population_size):
            if self.population[i].x_fitness > best_fitness:
                best_fitness = self.population[i].x_fitness
                best_individual = i
        print("Best Individual: ",str(best_individual)," \t", self.population[best_individual].x_vector, "\t Fitness: \t", str(best_fitness))
    
    def plot_evolved_candidate_solutions(self):
        fig = plt.figure()
        ax1 = fig.add_subplot(1,1,1,projection='3d')
        ax1.scatter(self.hacker_tracker_x,self.hacker_tracker_y,self.hacker_tracker_z)
        plt.title("Evolved Candidate Solutions")
        ax1.set_xlim3d(-100.0,100.0)
        ax1.set_ylim3d(-100.0,100.0)
        ax1.set_zlim3d(0.2,1.0)
        plt.show()

VectorLength = 2
ub = 100.0
lb = -100.0
MaxEvaluations = 4000
plot = 0

PopSize = 20#30
mu_amt  = 0.012

update = "S" # "A" for asynchronous or "S" for synchronous

w = 1 #inertia factor #gradually decrease this as a percentage of itself for each cycle
n = 3 #neighborhood (for Ring Topology)

"""
# Swarm Search 
v(id) = v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id))
x(id) = x(id) + v(id)


# The Inertia Factor
w = 1.0 #initialized #this will be gradually reduced over time
v(id) = w*v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id))
x(id) = x(id) + v(id)
"""

# Constriction Coefficient
phi1 = 2.05 #2.00
phi2 = 2.05 #2.00

phi = phi1 + phi2 #phi > 4
K = 2/abs(2 - phi - math.sqrt((phi*phi) - (4*phi)))

"""
phi = phi1 + phi2 #phi > 4  #4.10
K = 2/abs(2 - phi - sqrt((phi^2) - (4*phi)))
v(id) = K*(v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id)))
x(id) = x(id) + v(id)



# Full Model 
phi1 = 1 # phi1 > 0
phi2 = 1 # phi2 > 0
# Cognition Only 
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
# Social Only
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
# Selfless
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
g = 1 #g =/= i

# Asynchronous Update
# The Asynchronous self.population[i] Update Method allows for newly discovered solutions to be used more quickly.
# similar to SSGA


# Synchronous Update
# The Synchronous self.population[i] Update Method allows for ....
# similar to GGA
"""

for n in range(30):
    simple_exploratory_attacker = aSimpleExploratoryAttacker(PopSize,VectorLength,mu_amt,lb,ub)
    
    simple_exploratory_attacker.generate_initial_population()
#    simple_exploratory_attacker.print_population()
    
    for i in range(MaxEvaluations-PopSize+1):
        simple_exploratory_attacker.evolutionary_cycle()
#        if (i % PopSize == 0):
#            if (plot == 1):
#                simple_exploratory_attacker.plot_evolved_candidate_solutions()
#            print("At Iteration: " + str(i))
#            simple_exploratory_attacker.print_population()
        if (simple_exploratory_attacker.get_best_fitness() >= 0.99754):
            break
    
    #print("\nFinal Population\n")
    #simple_exploratory_attacker.print_population()
    simple_exploratory_attacker.print_best_max_fitness()
    #print("Function Evaluations: " + 
#    print(str(PopSize+i))
    simple_exploratory_attacker.plot_evolved_candidate_solutions()
    w += -w*0.01