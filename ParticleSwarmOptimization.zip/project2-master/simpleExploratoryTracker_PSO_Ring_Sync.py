#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 22:42:12 2019

@author: alj0032
"""

import os
import random
import sys
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

#
#  A Simple Steady-State, Real-Coded Genetic Algorithm       
#
    
class aparticle:
    def __init__(self, specified_dimension_length):
        self.x_vector = []
        self.p_vector = []
        self.v_vector = []
        self.x_fitness = 0
        self.p_fitness = 0
        self.dimension_length = specified_dimension_length
        
    def randomly_generate(self,lb, ub):
        for i in range(self.dimension_length):
            self.x_vector.append(random.uniform(lb, ub))
            self.p_vector.append(self.x_vector[i])
            self.v_vector.append(0)
        self.x_fitness = 0.5
        self.p_fitness = 0.5
    
    def calculate_fitness(self):
        x2y2 = self.x_vector[0]**2 + self.x_vector[1]**2
        self.x_fitness = 0.5 + (math.sin(math.sqrt(x2y2))**2 - 0.5) / (1+0.001*x2y2)**2
        if self.x_fitness > self.p_fitness:
            self.p_fitness = self.x_fitness
            self.p_vector = self.x_vector

    def print_particle(self, i):
        print("X_vector_Position "+str(i) +": \t\t " + str(self.x_vector) + "  \t Fitness: \t " + str(self.x_fitness))
      
class aSimpleExploratoryAttacker:
    def __init__(self, swarm_size, dimension_length, mutation_rate, lb, ub):
        if (swarm_size < 2):
            print("Error: Population Size must be greater than 2")
            sys.exit()
        self.swarm_size = swarm_size
        self.dimension_length = dimension_length
        self.mutation_amt = mutation_rate #########################SAME THING
        self.lb = lb
        self.ub = ub
        self.mutation_amt = mutation_rate * (ub - lb)##############SAME THING
        self.swarm = []
        self.hacker_tracker_x = []
        self.hacker_tracker_y = []
        self.hacker_tracker_z = []
        
    def generate_initial_population(self):
        for i in range(self.swarm_size):
            particle = aparticle(self.dimension_length)
            particle.randomly_generate(self.lb,self.ub)
            particle.calculate_fitness()
            self.hacker_tracker_x.append(particle.x_vector[0])
            self.hacker_tracker_y.append(particle.x_vector[1])
            self.hacker_tracker_z.append(particle.x_fitness)
            self.swarm.append(particle)
    
    '''def get_worst_fit_individual(self):
        worst_fitness = 999999999.0  # For Maximization
        worst_individual = -1
        for i in range(self.population_size):
            if (self.population[i].fitness < worst_fitness): 
                worst_fitness = self.population[i].p_fitness
                worst_individual = i
        return worst_individual'''
    
    def get_best_particle(self):
        best_fitness = -99999999999.0
        best_individual = -1
        for i in range(self.swarm_size):
            if self.swarm[i].p_fitness > best_fitness:
                best_fitness = self.swarm[i].p_fitness
                best_individual = i
        return best_individual
    
    '''def kid_vs_worst_fit_individual(self,kid):
        worst_individual_name = kid
        for i in range(self.population_size):
            if (self.population[i].fitness < self.population[kid].fitness):
                worst_fitness = self.population[i].fitness
                worst_individual = self.population[i]
                worst_individual_name = i
        kid = worst_individual_name
        return kid
    
    def select_parent(self):
        parent = random.randint(0,self.population_size-1)
        return parent'''
    
    def evolutionary_cycle(self):
        #Ring And Synchronous
        K = 2 / abs(2 - phi - math.sqrt((phi * phi) - (4 * phi)))
        p_globalbest = self.get_best_particle()
        for m in range(self.swarm_size):
            for j in range(self.dimension_length):
                term1 = self.swarm[m].v_vector[j]
                term2 = phi1*random.random()*(self.swarm[m].p_vector[j]-self.swarm[m].x_vector[j])
                term3 = phi2*random.random()*(self.swarm[p_globalbest].p_vector[j] - self.swarm[m].x_vector[j])
                self.swarm[m].v_vector[j] = K*(term1 + term2 + term3)
                #self.swarm[m].v_vector[j]= K*(self.swarm[m].v_vector[j] + phi1*random.random()*(self.swarm[m].p_vector[j]-self.swarm[m].x_vector[j]) + phi2*random.random()*(self.swarm[p_globalbest].p_vector[j] - self.swarm[m].x_vector[j]))
                self.swarm[m].x_vector[j] = self.swarm[m].x_vector[j] + self.swarm[m].v_vector[j]


        """
#        for j in range(self.chromosome_length):
#            #single-point,  two-point, or uniform crossover types: 
##            #Single Point Crossover (SPX)
##            cutpoint = 3
###            self.population[kid].chromosome[j] = random.uniform(self.population[mom].chromosome[j],cutpoint)#1:j],1)#,self.population[dad].chromosome[j:len(self.population[dad].chromosome)])#,random.uniform(self.population[mom].chromosome[cutpoint:j],1)#[self.population[mom].chromosome[1:cutpoint],self.population[dad].chromosome[cutpoint:len(self.population[dad].chromosome)]]
##            self.population[kid].chromosome[j] = random.uniform(self.population[dad].chromosome[j],cutpoint)#1:j],1)#,self.population[dad].chromosome[j:len(self.population[dad].chromosome)])#,random.uniform(self.population[mom].chromosome[cutpoint:j],1)#[self.population[mom].chromosome[1:cutpoint],self.population[dad].chromosome[cutpoint:len(self.population[dad].chromosome)]]
###            self.population[kid2].chromosome[j] = [self.population[dad].chromosome[1:cutpoint],self.population[mom].chromosome[cutpoint:len(self.population[dad].chromosome)]]
###            #Mid-Point Crossover (MPX)
##            self.population[kid].chromosome[j] = self.population[mom].chromosome[j]#,self.population[dad].chromosome[j:len(self.population[dad].chromosome)]]
###            self.population[kid].chromosome[j] = [self.population[mom].chromosome[1:j],self.population[dad].chromosome[j:len(self.population[dad].chromosome)]]
###            self.population[kid2].chromosome[j] = [self.population[dad].chromosome[1:j],self.population[mom].chromosome[j:len(self.population[dad].chromosome)]]
###            #Flat Crossover (BLX-0.0, or Blended Point Crossover)
#            self.population[kid].chromosome[j] = random.uniform(self.population[mom].chromosome[j],self.population[dad].chromosome[j])
#            self.population[kid].chromosome[j] += self.mutation_amt * random.gauss(0,1.0) #not sure what this is doing
#            if self.population[kid].chromosome[j] > self.ub:
#                self.population[kid].chromosome[j] = self.ub
#            if self.population[kid].chromosome[j] < self.lb:
#                self.population[kid].chromosome[j] = self.lb
        """
        #"""
        #BLX-0.0?
        for j in range(self.chromosome_length):
            self.population[kid].chromosome[j] = random.uniform(self.population[mom].chromosome[j],self.population[dad].chromosome[j])
            self.population[kid].chromosome[j] += self.mutation_amt * random.gauss(0,1.0)
            if self.population[kid].chromosome[j] > self.ub:
                self.population[kid].chromosome[j] = self.ub
            if self.population[kid].chromosome[j] < self.lb:
                self.population[kid].chromosome[j] = self.lb
        #"""
        """
        #Single Point Crossover
        mid = int(self.chromosome_length/2)
        for j in range(mid):
            self.population[kid].chromosome[j] = self.population[mom].chromosome[j]
            self.population[kid].chromosome[j] += self.mutation_amt * random.gauss(0,1.0)
            if self.population[kid].chromosome[j] > self.ub:
                self.population[kid].chromosome[j] = self.ub
            if self.population[kid].chromosome[j] < self.lb:
                self.population[kid].chromosome[j] = self.lb
        for k in range(mid, self.chromosome_length):
            self.population[kid].chromosome[k] = self.population[dad].chromosome[k]
            self.population[kid].chromosome[k] += self.mutation_amt * random.gauss(0,1.0)
            if self.population[kid].chromosome[k] > self.ub:
                self.population[kid].chromosome[k] = self.ub
            if self.population[kid].chromosome[k] < self.lb:
                self.population[kid].chromosome[k] = self.lb
        """
        """
        #Midpoint Crossover
        for j in range(self.chromosome_length):
            self.population[kid].chromosome[j] = ((self.population[mom].chromosome[j] + self.population[dad].chromosome[j])/2)
            self.population[kid].chromosome[j] += self.mutation_amt * random.gauss(0,1.0)
            if self.population[kid].chromosome[j] > self.ub:
                self.population[kid].chromosome[j] = self.ub
            if self.population[kid].chromosome[j] < self.lb:
                self.population[kid].chromosome[j] = self.lb
       """

        self.swarm[j].calculate_fitness()
#        kid = kid_vs_worst_fit_individual(self,kid) #not sure what this is doing
#        kid2 = kid_vs_worst_fit_individual(self,kid2) #not sure what this is doing
#        self.hacker_tracker_x.remove(self.population[])
        self.hacker_tracker_x.append(self.swarm[j].x_vector[0])
        self.hacker_tracker_y.append(self.swarm[j].x_vector[1])
        self.hacker_tracker_z.append(self.swarm[j].x_fitness)
#        self.hacker_tracker_x.append(self.population[kid2].chromosome[0])
#        self.hacker_tracker_y.append(self.population[kid2].chromosome[1])
#        self.hacker_tracker_z.append(self.population[kid2].fitness)
    
    def print_population(self):
        for i in range(self.swarm_size):
            self.swarm[i].print_particle(i)
    
    def print_best_max_fitness(self):
        best_fitness = -999999999.0  # For Maximization
        best_individual = -1
        for i in range(self.swarm_size):
            if self.swarm[i].p_fitness > best_fitness:
                best_fitness = self.swarm[i].fitness
                best_individual = i
        print("Best Individual: ",str(best_individual)," \t", self.swarm[best_particle].x_vector, "\t Fitness: \t", str(best_fitness))
    
    def plot_evolved_candidate_solutions(self):
        fig = plt.figure()
        ax1 = fig.add_subplot(1,1,1,projection='3d')
        ax1.scatter(self.hacker_tracker_x,self.hacker_tracker_y,self.hacker_tracker_z)
        plt.title("Evolved Candidate Solutions")
        ax1.set_xlim3d(-100.0,100.0)
        ax1.set_ylim3d(-100.0,100.0)
        ax1.set_zlim3d(0.2,1.0)
        plt.show()


    # def best_ring_fitness(self):
    #     for i in range(self.swarm_size):
    #         if i > 0 & i < (self.swarm_size - 1:
    #             best_fit_neighbor_1 = self.swarm[i-1].p_fitness
    #             best_fit_neighbor_2 = self.swarm[i+1].p_fitness
    #         elif i = 0:
    #             best_fit_neighbor_1 = self.swarm[swarm_size - 1]




DimensionLength = 2
ub = 100.0
lb = -100.0
MaxEvaluations = 4000
plot = 0

SwarmSize = 30#20#3
mu_amt  = 0.012#0.01 #0.0075


# Swarm Search 
# v(id) = v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id))
# x(id) = x(id) + v(id)


# The Inertia Factor
#w = 1.0 #initialized #this will be gradually reduced over time
# v(id) = w*v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id))
# x(id) = x(id) + v(id)


# Constriction Coefficient
phi1 = 2.05
phi2 = 2.05
phi = phi1 + phi2 #phi > 4  #4.10

# v(id) = K*(v(id) + phi1*random.gaussian()*(p(id)-x(id)) + phi2*random.gaussian()*(p(gd)-x(id)))
# x(id) = x(id) + v(id)



# # Full Model
# phi1 = 1 # phi1 > 0
# phi2 = 1 # phi2 > 0
'''# Cognition Only 
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
# Social Only
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
# Selfless
phi1 = 1 # phi1 > 0
phi2 = 0 # phi2 = 0
g = 1 #g =/= i'''

# Asynchronous Update
# The Asynchronous Particle Update Method allows for newly discovered solutions to be used more quickly.
# similar to SSGA


# Synchronous Update
# The Synchronous Particle Update Method allows for ....
# similar to GGA



for iter in range(30):
    simple_exploratory_attacker = aSimpleExploratoryAttacker(SwarmSize,DimensionLength,mu_amt,lb,ub)

    simple_exploratory_attacker.generate_initial_population()
    #simple_exploratory_attacker.print_population()

    for i in range(int(MaxEvaluations-SwarmSize+1)):
        simple_exploratory_attacker.evolutionary_cycle()

        #Ring Topology
        for iteration in range(SwarmSize - 1):
            best_fitness_for_i = best_ring_fitness()

        if (i % PopSize == 0):
            if (plot == 1):
                simple_exploratory_attacker.plot_evolved_candidate_solutions()
            #print("At Iteration: " + str(i))
            #simple_exploratory_attacker.print_population()'''
        if (simple_exploratory_attacker.get_best_fitness() >= 0.99754):
            break

    #print("\nFinal Population\n")
    #simple_exploratory_attacker.print_population()
    #simple_exploratory_attacker.print_best_max_fitness()
    print(str(PopSize+i))
    #simple_exploratory_attacker.plot_evolved_candidate_solutions()


    


    
